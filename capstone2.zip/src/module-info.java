module capstone {
	requires java.desktop;
}